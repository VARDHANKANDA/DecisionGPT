# RELATED_WORK_AND_RESEARCH_GAP

Every source below was located and its bibliographic details checked (publisher / DOI registry / ACL Anthology / arXiv API) either in earlier project sessions (`docs/PAPER_REFERENCES.md`) or on 2026-10-22 (marked *new*). Citation keys refer to `references.bib`. Claims are limited to what each source's own abstract or findings state. Searches were limited (a handful of targeted web searches plus the earlier literature pass); the gap statement is therefore **scoped to the sources reviewed**, not a claim about the whole literature.

## 1. Strands of related work

| Strand | Sources | What they establish | How we use them |
|---|---|---|---|
| Prescriptive analytics and decision support | Lepenioti 2020; Arnott & Pervan 2014; Shmueli & Koppius 2011 | prediction and prescription are different evaluation targets; predictive accuracy alone is not decision quality | motivates separating RQ1 (prediction) from RQ2 (decision quality) |
| Digital twin vs. digital model | Grieves & Vickers 2017; Tao 2019; Kritzinger 2018; Jones 2020 | a "twin" needs automatic bidirectional data flow; a simulation fed manually is a digital *model* | we call the simulator a *Decision Simulation* |
| Multi-agent LLM systems (pro) | Du 2023; Liang 2024; Li 2024; Wu 2023 (AutoGen); Hong 2023 (MetaGPT) | debate / many agents can raise reasoning or factuality scores; frameworks make multi-agent orchestration easy | context: the claim that more agents help; not evidence about rule-based agents |
| Multi-agent LLM systems (critical) | Wang 2024; Smit 2024; Huang 2024; Cemri 2025; Tran & Kiela 2026 (*new*); Fu et al. 2026 (*new*) | strong single agents can match multi-agent discussion; debate is hyper-parameter fragile; failure taxonomies; gains are often confounded with extra compute; most tested multi-agent workflows trail a matched single-agent reference | motivates a compute- and information-matched comparison and cost reporting |
| Agent definition | Wooldridge & Jennings 1995 | what "agent" has to mean (autonomy, reactivity, …) | we use "agent" for a rule-based scoring role and say so |
| Forecast evaluation | Makridakis 2020, 2022; Hyndman & Koehler 2006 | scale-free metrics, baselines, intermittent demand; MAPE fails near zero | WAPE with zero-denominator policy; strong simple baselines |
| Statistical practice | Efron 1979; Wilcoxon 1945; Holm 1979; Fritz 2012; Kerby 2014; Wasserstein & Lazar 2016; Nosek 2018; Baker 2016; Pineau 2021 | resampling, rank tests, multiplicity, effect sizes, preregistration, reproducibility | analysis plan and reporting |
| Risk-sensitive objectives | García & Fernández 2015 | additive risk terms are a recognised family; weights are a design choice | interpretation of the risk term in the optimizer (no causal claim) |
| SME context | OECD 2021; Buteau 2021 | data and skills constraints of SMEs, informal records in India | motivation only; no evidence about DecisionGPT |

## 2. Research gap (scoped)

1. Multi-agent comparisons in the sources reviewed evaluate **LLM agents on reasoning, coding or tool benchmarks**; the critical ones show the advantage can vanish under matched compute or against a strong single agent. We found **no source in our searches that isolates the contribution of an orchestration layer in a simulator-based decision-support pipeline** against an *exogenous* ground-truth objective with the *same* simulated evidence given to every workflow. (A search-based statement; not a claim that no such study exists.)
2. Digital-twin decision-support papers typically report the usefulness of the simulator or an application case; a **component ladder** (prediction → simulation → one agent → multi-agent) scored by regret against an independent objective, with the number of invocations per workflow, is not what the retrieved sources report.
3. The honest consequence for a small system: a **controlled negative or null result is publishable evidence** if the design is fair (same inputs, same decision set, exogenous scoring, scenario as unit, locked protocol), and it is exactly what practitioners need before adding orchestration cost.

## 3. Positioning statement (used in the paper)

> We do not propose a new decision algorithm. We ask whether the multi-agent layer of an existing, fully deterministic SME decision-support architecture adds decision quality over a prediction-plus-simulation baseline when every workflow receives the same simulated evidence, and what each layer costs. Evidence is synthetic and scored by an exogenous ground-truth objective; agents are rule-based, not language models.

## 4. What we will not claim

* that multi-agent systems are or are not helpful in general;
* that results transfer to real SMEs, to LLM agents, or to profit;
* novelty beyond the scoped gap above ("to our knowledge" is avoided; the searches are disclosed as limited).

## 5. Verification log for sources added on 2026-10-22

| Key | Check | Result |
|---|---|---|
| Makridakis2022 (M5) | Crossref 10.1016/j.ijforecast.2021.11.013 | IJF 38(4), 1346–1364, 2022 – matches |
| Makridakis2020 (M4) | Crossref 10.1016/j.ijforecast.2019.04.014 | IJF 36(1), 54–74, 2020 – matches |
| Efron1979 | Crossref 10.1214/aos/1176344552 | Ann. Statist. 7(1), 1–26 – matches |
| Wooldridge1995 | Crossref 10.1017/S0269888900008122 | Knowl. Eng. Rev. 10(2), 115–152 – matches |
| Holm1979 | web search of bibliographic listings (not in Crossref) | Scand. J. Statist. 6(2), 65–70; DOI 10.2307/4615733 per JSTOR listing |
| Wu2023AutoGen | arXiv API 2308.08155 | title/authors/date match |
| Hong2023MetaGPT | arXiv API 2308.00352 | title/authors/date match |
| Tran2026 | arXiv API 2604.02460 | title/authors/date match; abstract read (single-agent matches or beats multi-agent under fixed reasoning-token budgets) |
| Fu2026 | arXiv API 2606.05670 | title/authors/date match; abstract partly read (6 workflows vs a single-agent reference, 10 benchmarks, GPT-4.1) |

Preprints are cited as preprints; none supports a claim about this project's results.
