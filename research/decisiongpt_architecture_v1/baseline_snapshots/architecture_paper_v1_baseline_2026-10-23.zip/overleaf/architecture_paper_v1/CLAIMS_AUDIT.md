# CLAIMS_AUDIT — every substantive claim in the paper, its evidence, and its status

Numbers in the paper are LaTeX macros generated from `research/decisiongpt_architecture_v1/results/*.json` (`tables/numbers.tex`); `analysis/scan_numbers.py` lists the few literals typed by hand (design constants: 70/15/15 split, 34 scenarios per family, 10 seeds, 350 series, 28 days, 90 days, thresholds, instance counts) — each is checked below against its source file. Status: **S** supported by stored/new evidence as worded; **Q** supported only with the qualification written in the paper; **R** removed or never made.

## A. Design and scope claims

| # | Claim in the paper | Evidence | Status |
|---|---|---|---|
| A1 | The three agents are rule-based scoring functions; no language model is on the decision path | `backend/app/agents/*.py`, `llm_service.py` (template methods; `evaluate_agent`, `generate_strategy_explanation` are templates), E-COST counted 0 client requests (`cost_summary.json: counts_per_decision.llm_network_requests_attempted_all`) | S |
| A2 | All four workflows receive the same simulated evidence and feasible action set | `harness.py` (`_sim_all`, identical-action-space invariant: 0 violations in 4 080 + 800 instances) | S (note: D recomputes its own simulation from the same history and model; its inputs are identical but the simulation is run twice) |
| A3 | Condition A is a reference scored as the minimal-intervention action | `ground_truth.score_selection`, `_noop_action`; Amendment 1 | S |
| A4 | Greedy and classical optimizer are informed references | `ground_truth.py` docstrings; `docs/R1_INFORMATION_BOUNDARY.md` | S |
| A5 | The R1 wrapper changes only the scenario-side units/revenue/profit of the Decision Simulation | `docs/R1_DT_DIAGNOSTIC.md`, `backend/app/evaluation/r1/r1_dt.py` (read); not independently re-verified byte-for-byte here | Q (stated as the project's documentation) |
| A6 | The R1 scenario manifest and seeds were fixed before the one-shot run | `docs/R1_PREREGISTRATION.md` (frozen at git 22ce18c per project record); not re-verified from git history in this task | Q |
| A7 | The scorer is deterministic and has no risk/variance term | `ground_truth.py` header | S |

## B. Results claims

| # | Claim | Evidence | Status |
|---|---|---|---|
| B1 | R1: D − B > 0 with CI excluding 0, Holm p < 1e-4; D worse in most families | `decision_quality.json`, `replication_check.json` (means and p-values match the stored statistical results) | S |
| B2 | R1: B − A < 0 (simulation helps) | same | S, with A defined as minimal intervention |
| B3 | R1: C − B inconclusive (mean CI excludes 0, rank test null, first-seed rank p = 0.012) | `decision_quality.json`, `sensitivity.json` | S as "inconclusive"; **no direction claimed** |
| B4 | R1: loss concentrates at C → D | D − C larger than D − B; C − B small | Q (associational; the paper says "arises at the step", not "is caused by the risk term") |
| B5 | Upgraded v1: D − B inconclusive; D worse than A | `decision_quality.json` | S |
| B6 | Upgraded v1: B − A mean positive but rank test significant — "mixed, no benefit claimed" | same | S |
| B7 | D better only in saturating/nonlinear families | `by_family` (exploratory, no multiplicity control) | Q (exploratory label in text and caption) |
| B8 | D changes B's action in 57 % of decisions, worsens more than improves; optimal-action rate 62.5 % → 34.6 % | `experiments/r1/mechanism_results.json` (stored) | S as descriptive counts |
| B9 | Robustness: 1 620 perturbed runs, 10 types, primary conclusion unchanged | `experiments/r1/robustness_results.json` (`primary_conclusion_changes: false`) | S (stored result, subsample) |
| B10 | Excluding fallback instances / first seed / re-run on new date leaves D − B ≈ +0.08 to +0.11 | `sensitivity.json`, `cost_summary.json: rerun_on_new_date` | S |
| B11 | Risk term is a hypothesis for the mechanism | earlier internal diagnostic on another suite, not repeated | Q — wording is "hypothesis, not a finding" |

## C. Cost claims (RQ4)

| # | Claim | Evidence | Status |
|---|---|---|---|
| C1 | Medians/p95 of end-to-end time per workflow; D/B ratio with CI | `cost_summary.json` (408 scenarios, first seed) | S (one machine, other processes running) |
| C2 | Orchestration overhead (D minus its own simulation time) is ~10 % of D | `cost_summary.json: components_seconds.D_overhead` | Q (includes persistence to the scratch DB; ordering/cache effect: shared simulation always ran first) |
| C3 | 0 language-model requests; token/API cost 0 by construction | instrumentation + code reading | S; no hypothetical LLM-agent cost is claimed |
| C4 | Quality–cost frontier from measured pairs | `cost_summary.json: quality_cost` | Q (post-hoc; A is a proxy) |
| C5 | Re-run reproduces stored regrets and selected actions: A, B, C in all 408 instances; D in 403 of 408 (5 differ; capacity-bound ×2, demand-saturation ×2, nonlinear-response ×1); attributed to date-anchored histories, near-tie explanation NOT tested | `cost_summary.json: determinism_matches_stored`, `rerun_on_new_date` | S — exact counts in the paper are macros |

## D. RQ1 claims

| # | Claim | Evidence | Status |
|---|---|---|---|
| D1 | M5 CA_1: learned models beat seasonal naive at item level; same-weekday mean best at store-total level; ensembles no gain | `ml_benchmark_v1/f1_*/results.json` (stored; reproduced by the `reproduce` run with 0.0 difference per the benchmark report) | S |
| D2 | No family wins everywhere (CatBoost best on M5, near-worst on top-20 SKUs) | `f1`, `f2` results | S |
| D3 | Customer-inactivity label is a proxy; ensembles no gain; recalibration worsened test calibration | `c1` results | S |
| D4 | Registry models re-scored from stored artifacts reproduce recorded metrics (v1: 3 of 3) | `rq1_summary.json: registry_rescoring` (from `models.lifecycle_json`; verification field `stored_metrics_matched: true`) | S; v2 models excluded with reason |
| D5 | Production forecaster is nearly flat in price | `ML_BENCHMARK_REPORT.md` §6 (±10 % price → −0.045 % / +0.04 % units); SHAP share ≈ 2.2 % from registry metrics | S |

## E. Claims deliberately NOT made

Multi-agent systems are unhelpful in general; results transfer to real SMEs, profit, or causal effects; language-model agents behave similarly; the architecture is validated, deployable, or superior; the paper is pre-registered; novelty ("first"); a risk-adjusted-utility verdict; any statement about token cost of LLM agents; the term "accuracy" for continuous forecasts.

## F. Wording audit

* Forbidden-claim scan of the LaTeX sources (`analysis/` helper run at the end; result in `FINAL_REVIEW_REPORT.md`): no occurrence of "validated for", "outperforms" about the architecture, "proves", "state-of-the-art", "novel", "first to", "real-world".
* Hedges present where required: "in the sources we reviewed", "not a claim of absence", "synthetic", "exploratory", "post-hoc".
