# ARCHITECTURE_AUDIT — what DecisionGPT actually implements (read from the code, 2026-10-22)

Purpose: fix, before any claim is written, which components exist, which are deterministic, and which are only documented. Every row cites the file that was read. Nothing here is a statement about real SMEs.

## 1. Implemented components (verified in the repository)

| Component | Implementation | Deterministic? | Evidence file |
|---|---|---|---|
| Data ingestion and canonical schema | CSV/.xlsx upload, transparent cleaning (values never altered), column mapping, per-business scoping (`business_id` on every table) | yes | `backend/app/services/data_ingestion_service.py`, `canonical_schema.py`, `column_mapping.py` |
| Forecasting | direct models registered in the `models` table: naive (lag), linear, XGBoost; chronological 70/15/15 split; MAE/RMSE/MAPE (+ WAPE where re-scored) | yes (seeded) | `ml/training/train_forecasting.py`, `ml/evaluation/metrics.py`, `backend/app/analytics/forecast_service.py` |
| Customer-inactivity model | logistic regression / random forest / XGBoost on synthetic platform data (7 production features) | yes (seeded) | `ml/training/train_churn.py` |
| Decision Simulation ("Digital Twin") | runs the registered forecasting model twice per candidate (baseline vs. scenario with price/marketing/inventory changes) and differences the outputs; it is a **digital model** in the Kritzinger taxonomy (no automatic bidirectional data flow) | yes | `backend/app/analytics/digital_twin_service.py` |
| Candidate-strategy generator | fixed grid of 6 candidates in production (`CANDIDATE_GRID`: marketing +10/+5/−10, price +5/−5, marketing +10 & price −5) | yes | `backend/app/services/decision_service.py` |
| Business Analyst, Financial Advisor, Risk Manager | **pure functions** of the simulation output (no LLM call inside the decision path); round-1 scores then a round-2 peer-review adjustment | yes | `backend/app/agents/{business_analyst,financial_advisor,risk_manager,base}.py` |
| Strategy optimizer | `score = mean(BA, FA) − (1 − RM)` (formula version v2); round-2 debate adjusts scores, records conflicts, derives a documented confidence | yes | `backend/app/agents/strategy_optimizer.py` |
| Single-agent baseline | `growth_score × (1 − risk_score)` | yes | `backend/app/agents/single_agent.py` |
| Causal / explainability / memory modules | exist and are stored with a decision for traceability; none of them changes the selected strategy's numbers in the evaluated configuration | yes | `causal_*_service.py`, `explainability_service.py`, `memory_service.py` |
| Language-model facade | OpenAI Responses API, **only** (i) closed-vocabulary classification of a question/goal text, (ii) restating verified facts, shown only if a deterministic validator passes; **not** used for forecasts, scores, strategies or agent reviews. Disabled when no key is configured; a rule-based path always exists | n/a (not in the decision path) | `backend/app/services/llm_service.py`, `openai_client.py`, `AGENTS.md` |
| Exogenous evaluation harness | scenario families, a ground-truth objective that is a different functional form from the simulator, an oracle, naive/greedy/classical-optimizer references, a scenario-level paired statistics module | yes | `backend/app/evaluation/*` |
| Research Console | admin-only evaluation and traceability pages reading stored experiment runs and registered models | n/a | `backend/app/api/v1/endpoints/research/*`, `frontend/src/app/research/*` |

## 2. Architecture variants evaluated (the only ones the paper compares)

| Label | Definition (code) | What it is |
|---|---|---|
| A | forecasting only; **recommends nothing**, scored as the status-quo / minimal-intervention action (`ground_truth._noop_action`: the no-op if it is in the decision set, otherwise the smallest-magnitude feasible action) | a reference policy, not a decision-support architecture (Amendment 1) |
| B | A + Decision Simulation; picks the feasible action with the highest simulated KPI (greedy) | prediction + simulation |
| C | B + one rule-based agent (`single_agent.evaluate`); picks the highest agent score | one-agent layer |
| D | the unchanged production pipeline `decision_service.analyze_goal` (3 agents, 2 rounds, optimizer, risk gate), default options | multi-agent layer |
| references | oracle (exhaustive over the feasible set, ground-truth objective), naive, greedy (local first-order heuristic using the *true* objective), classical optimizer (continuous relaxation of the *true* closed-form objective, projected to the discrete set) | exogenous, never call DecisionGPT; **informed references** (they see the ground-truth objective, which no deployed policy sees), so they bound what is achievable, not what is a fair competitor |

The same feasible action set and the same simulated outputs are given to B, C and D (`harness._sim_all`, identical-action-space invariant verified per instance).

## 3. What does NOT exist (so the paper must not claim it)

* **No LLM-based agents.** The "multi-agent" layer is three rule-based scoring functions plus a rule-based optimizer. Findings concern deterministic orchestration around a simulator, not LLM agent societies.
* **No real-SME evidence.** No real Indian SME outcome record exists in the repository (workflow ready, 0 records). No real-LLM evaluation exists (blocked: no configured evaluation provider).
* **No causal validation.** `CAUSALLY_VALIDATED` count is 0; causal edges are stored associations/graph versions.
* **No token usage or API cost** in the decision path; any cost figure in the paper is compute time. Hypothetical LLM-agent costs are not reported as results.
* **Production Digital Twin price response is flat** (measured: ±10 % price changes total predicted units by −0.045 % / +0.04 %; `docs/ML_BENCHMARK_REPORT.md` §6), which is why a research-only corrected Decision Simulation (R1) exists; R1 is not part of the production code.

## 4. Existing locked evidence that the paper re-analyses (read-only)

| Study | Scale | Where | Pre-registration |
|---|---|---|---|
| R1 locked evaluation | 12 families × 34 scenarios = 408 scenarios × 10 seeds = 4 080 decisions/condition, research-only corrected Decision Simulation, 0 errors | `experiments/r1/` | `docs/R1_PREREGISTRATION.md`, frozen at git `22ce18c` before the one-shot run |
| Upgraded controlled v1 | 4 families × 20 scenarios = 80 scenarios × 10 seeds = 800 instances, production Decision Simulation | `experiments/upgraded_controlled_v1/` | `docs/UPGRADED_EVALUATION_PREREGISTRATION.md` |
| ML benchmark v1 | M5 CA_1 (350 series), Online Retail II, customer-inactivity proxy label, synthetic churn, price-response identification | `experiments/ml_benchmark_v1/` | `docs/ML_IMPROVEMENT_PLAN.md` |
| Model comparison v1 | POS daily revenue, platform units | `experiments/model_comparison_v1/` | – |

The frozen manifest `experiments/experiment_manifest.json` (sha256 `94aa419c703b1babb465975463b26e55255755a7687ecbecadb6db4c4c15cbff`) is checked before and after every analysis of this paper (`research/decisiongpt_architecture_v1/results/input_hashes_*.json`).

## 5. Gaps the audit found in the existing evidence (addressed or disclosed by this paper)

| Gap | Handling |
|---|---|
| Stored `latency_seconds` for A–C exclude the shared simulation, D includes its whole pipeline: **not comparable** across conditions | new end-to-end timing measurement (E-COST), same code, same scenarios |
| No existing measurement of invocation counts per workflow | E-COST counts simulator calls, forecasting-model runs, agent evaluations and LLM-facade calls |
| Two locked studies use different simulators (production vs. R1-corrected) and different families | reported side by side, never pooled |
| Condition A is a status-quo-proxy, not "no action" | disclosed in §2 and in the paper's Table of conditions |
| Protocol written after the locked studies were run and inspected | disclosed; new analyses are labelled *new measurement / replication / post-hoc*; no preregistration claim for this paper |
| Cost cannot include LLM tokens (none used) | stated as 0 by construction; no estimate of a hypothetical LLM-agent variant is presented as a result |
