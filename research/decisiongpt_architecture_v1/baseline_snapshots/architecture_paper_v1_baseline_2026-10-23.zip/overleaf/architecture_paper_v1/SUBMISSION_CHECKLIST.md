# SUBMISSION_CHECKLIST (updated 2026-10-23)

Legend: DONE (verified) · TODO-AUTHORS · UNVERIFIED (could not be confirmed from an official page).

## 1. Target venue — IEEE COMPSAC 2027 (checked on official pages, 2026-10-23)

Sources: <https://ieeecompsac.computer.org/2027/> · <https://ieeecompsac.computer.org/2027/information-for-authors/> · <https://ieeecompsac.computer.org/2027/call-for-papers/> · COMPSAC FAQ wiki (2026 content only): <https://rm.compsac.net/projects/public/wiki/Wiki>.

| Item | Official statement (as fetched) | Status |
|---|---|---|
| Conference | 51st IEEE COMPSAC, Tokyo, 13–16 July 2027; theme "Trusted Agentic Ecosystems Engineering for Autonomous Intelligence" | DONE — fits (agentic/multi-agent software architecture, controlled evaluation); the CFP lists no tracks, so confirm the track in the submission system |
| Full-paper deadline | **31 January 2027**; time zone not stated on 2027 pages (the 2026 FAQ said 23:59 AoE) | time zone UNVERIFIED — assume 23:59 AoE, submit well before. (An earlier "15 Oct 2026" date found on the Computer Society page is the *workshop-proposal* deadline, not the paper deadline.) |
| Notification / camera-ready | 7 April 2027 / 1 June 2027 | DONE |
| Page limit | "Full conference papers: 10 pages", **inclusive of tables, figures, appendices and references**; up to 2 extra pages at $125 USD/page | DONE — this manuscript is **10 pages including references** (page 10 is references only) |
| Format | IEEE templates (Word / LaTeX / Overleaf); US Letter | DONE — IEEEtran conference class, US Letter default |
| Review mode | **Double-blind**: remove names, affiliations and contacts from the header; redact references to authors' names, affiliations or prior works | DONE — default build is anonymous (see §2) |
| Generative-AI policy | AI-generated content must be disclosed in the acknowledgments, identifying the system | DONE — `sections/09_acknowledgment.tex` (authors to review and confirm the wording is accurate) |
| Plagiarism / dual submission | CrossCheck screening; simultaneous submission elsewhere not permitted | **see §3 (overlap with the authors' earlier manuscript)** |
| Submission system / portal | not stated on the 2027 pages (the 2026 FAQ mentions EasyChair only for resubmission/withdrawal; camera-ready via the IEEE CPS system) | UNVERIFIED — the link will appear on the 2027 site; contact address given on the FAQ page |
| Registration/presentation obligations | not stated on the fetched pages | UNVERIFIED |

Fallback venue (judgement, not verified): none is needed while COMPSAC 2027 is open; if it is missed or rejected, IEEE Access (continuous submission) is the realistic fallback, but its current scope, fees and length rules were **not** checked.

## 2. Anonymisation and author information

* `main.tex` builds the **anonymous** PDF by default ("Anonymous Authors"); `\camerareadytrue` loads `private/author_block.tex`. The camera-ready variant was test-built (10 pages).
* **Author details reused exactly** from the authors' previous paper: names K. S. Sri Vardhan, R Rohit, K. Rahul, and Felix (this order); SCOPE, VIT-AP University, Vijayawada, Andhra Pradesh, India; the four institutional e-mail addresses printed there. Sources: `overleaf/main.tex` `\author{}` (also `C:\Users\VARDHAN\Downloads\overleaf\main.tex`) and page 1 of `C:\Users\VARDHAN\Downloads\DecisionGPT (1).pdf`; all three agree. No corresponding-author or supervisor designation is documented in the source, so none was added; no funding or ethics statement was invented.
* TODO-AUTHORS: confirm the author list/order is still correct for *this* manuscript (a conflict would only arise if it differs from the previous paper).
* Anonymous PDF checked: no names, affiliations or e-mail addresses in the text; PDF `Author` metadata empty, `Creator` empty. Do **not** upload `private/` or share the Overleaf folder with reviewers. The system name "DecisionGPT" appears in the abstract and text; if the authors' earlier paper is public, consider replacing it with a neutral name for the blind version (a global find-and-replace).
* The bibliography contains one anonymised self-reference (`AnonymousPrior`, "Details withheld for double-blind review"). For the camera-ready version replace it with the real citation.

## 3. Originality / overlap — decision needed from the authors

The authors' earlier manuscript (`DecisionGPT (1).pdf`, compiled 2026-09-17) already reports the **R1 locked 408-scenario replication** (same data: mean difference, p = 5.4×10⁻¹⁰, 274 of 408 worse). This paper discloses that (§IV-A, ref. [37]) and adds: the component-ladder framing, an independent re-analysis with a replication check, a second locked study (80 scenarios), sensitivity analyses, the new end-to-end cost measurement, and the RQ1 summary. Before submitting, the authors must decide and confirm: (a) the earlier manuscript is **not** under review elsewhere or already published (COMPSAC forbids simultaneous submission and screens with CrossCheck); (b) if it is public (e.g. a preprint or published paper), cite it in the camera-ready version and be prepared to explain the delta. Note also that the earlier manuscript's PDF shows unresolved citations ("[?]"), i.e. it was compiled without its bibliography — not relevant to this paper but worth fixing there.

## 4. References (reconciliation with the earlier paper)

Earlier-paper bibliography: 14 entries (`overleaf/references.bib`). Retained here because they are relevant and already present or verified: Kritzinger 2018, Lepenioti 2020, Arnott & Pervan 2014, Shmueli & Koppius 2011, Hyndman & Koehler 2006, Buteau 2021 (SME motivation). **Added from the earlier paper**: Chen & Guestrin 2016 (XGBoost; the registered model), Bulling 2014 (multi-agent decision-making survey), Makridakis et al. 2022 (M5 background paper, alongside the M5 results paper). Not reused (not relevant to this paper's claims): Granger 1969, Spirtes 2001, Pearl 2009 (causal module not evaluated here), Doshi-Velez & Kim 2017 (explainability not evaluated), the UCI *Online Retail* (2015) entry (a different dataset from the *Online Retail II* data used here) and the e-commerce dataset entry.
New references added in this task: Makridakis 2020 (M4) and 2022 (M5 results), Efron 1979, Holm 1979, Wooldridge & Jennings 1995, AutoGen, MetaGPT, Tran & Kiela 2026 and Fu et al. 2026 (arXiv preprints). Verification record: `RELATED_WORK_AND_RESEARCH_GAP.md` §5. **Bulling 2014 and the M5 background paper take their metadata from the authors' earlier bibliography; Chen 2016 was verified in an earlier session; a re-check against Crossref was attempted on 2026-10-23 but the network was unreachable, so re-verify these two (and `Holm1979`, absent from Crossref) before submission.** Citation check: 38 bibliography entries, 38 cited, none missing (`analysis/check_bib.py`); verification notes were removed from the printed references.

## 5. Manuscript status

| Item | Status |
|---|---|
| Compiles (TinyTeX pdfLaTeX + BibTeX), no undefined references/citations | DONE — 10 pages, page 10 references only |
| All numbers generated from `research/decisiongpt_architecture_v1/results/*.json` | DONE (macros; hand-typed literals reviewed in `CLAIMS_AUDIT.md`) |
| Claims audit, reviewer report | DONE (`CLAIMS_AUDIT.md`, `FINAL_REVIEW_REPORT.md`) |
| Frozen manifest / protocol hashes unchanged | DONE (`input_hashes_after.json` vs `before`; manifest `94aa419c…`, protocol `e1ebe5bb…`) |
| Data / code availability statement | DONE in text; TODO-AUTHORS: pick a repository and licence |
| Funding, competing interests, ethics | none declared in the text; TODO-AUTHORS if any apply |
| Keywords | DONE |

## 6. Exact steps in the submission portal (once the COMPSAC 2027 site opens it)

1. Find the portal link on the COMPSAC 2027 pages; create/log in to the account with an author e-mail.
2. Choose the full-paper category (10 pages, double-blind) and the track closest to "agentic / multi-agent software architecture evaluation".
3. Enter the title and abstract; add authors as the portal requires (the portal, not the PDF, holds identities).
4. Upload `main.pdf` built in the default anonymous mode (rebuild after any edit; confirm no names in the PDF text and empty author metadata).
5. Declare the generative-AI use consistent with the acknowledgment text, and confirm no simultaneous submission of this work elsewhere (see §3).
6. Submit before 31 January 2027 (23:59 AoE assumed); keep the confirmation.
7. After acceptance: build the camera-ready version (`\camerareadytrue`), replace the anonymous reference, add acknowledgments/funding, use the IEEE CPS system by 1 June 2027.
