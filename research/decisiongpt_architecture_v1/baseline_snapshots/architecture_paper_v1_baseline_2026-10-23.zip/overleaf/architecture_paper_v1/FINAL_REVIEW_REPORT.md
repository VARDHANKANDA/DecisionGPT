# FINAL_REVIEW_REPORT — skeptical-reviewer assessment and final validation (2026-10-23)

## 1. What the paper claims (one paragraph)
In a fully deterministic SME decision-support architecture, the multi-agent layer (three rule-based agents + optimizer + risk gate, "D") does **not** improve decision quality over prediction-plus-simulation ("B") in two locked synthetic studies: it is worse in the larger, well-specified-simulator study (R1, 408 scenarios) and inconclusive in the smaller one (80 scenarios). The one-agent step ("C") is inconclusive. The extra layers cost ~0.36 s (~8 % of D's time) over the simulator and use no language model. The evidence is synthetic; the agents are not language models.

## 2. Verified results (all from `research/decisiongpt_architecture_v1/results/*.json`; paper numbers are generated macros)
| Item | Result |
|---|---|
| R1 D − B | +0.085, 95 % cluster-bootstrap CI [+0.047, +0.122], Holm p < 1e-4, W/T/L 99/35/274; independent re-computation reproduces every stored mean and p |
| R1 B − A / C − B / D − C | −0.044 (Holm < 1e-4) / −0.054 but rank test null (Holm 0.609; first-seed rank p 0.012) → inconclusive / +0.139 (Holm < 1e-4) |
| Upgraded v1 D − B, C − B, D − A | +0.034 [−0.079, +0.144] Holm 1.0 / +0.030 Holm 1.0 / +0.109 Holm 0.003 |
| Sensitivity | excluding 69 fallback instances +0.085; first seed only +0.078; leave-one-family-out +0.050…+0.159; re-run on a new date +0.075 |
| Cost (408 scenarios, first seed) | median 4.00 s (B), 4.00 s (C), 4.35 s (D); D/B 1.08 [1.06, 1.10]; orchestration overhead 0.36 s (8 %); 0 model requests; within-scenario timing CV ≈ 34–38 % (noisy; only ratios interpreted) |
| Quality–cost | D is dominated (B and C cheaper and better); C lowest regret |
| RQ1 | M5 CA_1: CatBoost WAPE 0.698 vs 0.869 seasonal naive (−0.171, CI [−0.198, −0.144]); same-weekday mean best on store totals; no family wins on every dataset; ensembles no gain; proxy-label inactivity ROC-AUC 0.794–0.799; registry v1 models re-scored and verified (XGBoost WAPE 0.096 vs 0.156) |

## 3. Reviewer attack surface and our response
| # | Likely criticism | Status / response in the paper |
|---|---|---|
| 1 | "Agents are not LLM agents; title overreaches." | Stated in abstract, intro, discussion; title is a question about "a multi-agent layer"; recommend adding "rule-based" to the title if the venue wants it |
| 2 | "Synthetic benchmark authored by the same team." | Disclosed (discussion, abstract); no real-SME claim; real-outcome data named as the next step |
| 3 | "Ground truth ignores risk, so a risk-averse optimizer is penalised." | Discussed as construct validity; no risk-adjusted claim |
| 4 | "A is not 'no action'." | Defined as minimal-intervention reference (Amendment 1, Table text) |
| 5 | "Informed references are unfair." | Marked `*`, labelled informed references, not used as competitors |
| 6 | "Protocol written after results." | Disclosed; no pre-registration claim; locked studies were pre-registered separately |
| 7 | "Two studies, different simulators, pooled?" | Never pooled; reported side by side |
| 8 | "Mean CI and rank test disagree (C−B, B−A)." | Both reported; "inconclusive" |
| 9 | "Timing is noisy." | CV reported; only the ratio interpreted; one machine, concurrent load disclosed |
| 10 | "Re-run is not bit-identical." | 5 of 408 re-run instances differ (D only); calendar anchoring; contrasts unchanged; not described as "perfectly deterministic" |
| 11 | "Stored documentation inconsistent (0 % fallback, WTL orientation)." | Reported as discrepancies (§VII), sensitivity shows no effect |
| 12 | "Why no cost in dollars/tokens?" | No LLM is called; 0 by construction; no hypothetical LLM-agent cost presented |
| 13 | "Mechanism claim unsupported." | Stated as associational / hypothesis; earlier diagnostic not repeated on R1 |

## 4. Remaining limitations (not fixable without new data or experiments)
Synthetic evidence only; deterministic agents only; single code base; about eight candidate actions; exploratory family-level and quality–cost analyses; not pre-registered; timing on one loaded machine; the near-tie explanation of the 5 re-run flips was not tested; the R1 wrapper and prereg freeze are cited from project documentation (not re-verified from git in this task).

## 5. Validation performed
| Check | Result |
|---|---|
| LaTeX build (TinyTeX pdfLaTeX + BibTeX) | succeeds, `main.pdf` 10 pages, no undefined references/citations, three minor overfull-box warnings (≤ 26 pt, in a table caption/paragraph; no clipped content seen) and two font-shape warnings (italic small caps) |
| PDF visual inspection (pages rendered and viewed: title/abstract, tables, figures 1–4) | no clipped tables or broken figures observed |
| Bibliography | 38 entries, 38 cited, no missing keys (after removing two uncited and adding three references reused from the authors' earlier paper plus one anonymised self-citation); AutoGen, MetaGPT, Tran 2026, Fu 2026 verified against the arXiv API; M4, M5, Efron, Wooldridge–Jennings against Crossref; Holm 1979 via bibliographic listings (not in Crossref) |
| Hand-typed numbers | `scan_numbers.py` list reviewed; all are design constants traced in `CLAIMS_AUDIT.md`; one false literal (0.0 % fallback) found and corrected |
| Frozen artifacts | `input_hashes_after.json` vs `before`: 61 files unchanged; manifest sha256 `94aa419c…cbff`; protocol sha256 `e1ebe5bb…4345` matches `PROTOCOL.sha256`; `experiments/r1/results.json` hash unchanged by the cost script (asserted in-script) |
| Secret scan (paper + research dirs) | no API keys / private keys found |
| Forbidden-term scan of sections/tables | only negated uses ("does not claim … validated for deployment") |
| Analysis tests | `tests/unit/test_architecture_paper_analysis.py` 8 passed |
| Full backend suite | last full run (before the paper-analysis tests were added): 1825 passed, 35 skipped, 0 failed, exit 0 (4897 s); the 8 new tests were then run separately and pass |
| Cost run | 408 main + 96 repeat instances recorded, 0 errors, no duplicates; the repeat phase was interrupted once by a tool timeout and resumed from the append-only file without re-running completed instances |

## 6. Verdict
Scientifically defensible **as a scoped controlled-evaluation / negative-result paper**. Not defensible as evidence that the architecture works for real SMEs or that multi-agent systems are unhelpful in general. Formatting: IEEEtran conference class, 10 pages **including references**, which meets the COMPSAC 2027 full-paper limit (10 pages incl. references, double-blind; checked on the official pages 2026-10-23). The default build is anonymous; see `SUBMISSION_CHECKLIST.md` for the overlap with the authors' earlier manuscript (it already reports the R1 locked study) — a decision the authors must take before submitting.
